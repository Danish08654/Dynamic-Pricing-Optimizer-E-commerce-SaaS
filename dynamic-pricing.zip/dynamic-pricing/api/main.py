import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schema import PricingRequest, PricingRecommendation

app = FastAPI(
    title="Dynamic Pricing Optimizer",
    description="Real-time optimal price recommendations with A/B test support",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Load at startup
demand_model = xgb.XGBRegressor()
demand_model.load_model("demand_model.json")

le_cat         = joblib.load("le_category.joblib")
elasticity_df  = joblib.load("elasticity_data.joblib")

with open("pricing_metadata.json") as f:
    metadata = json.load(f)

FEATURES = metadata["demand_features"]


def predict_demand(price, category_enc, base_price, competitor_price,
                   day_of_week, month, is_weekend, season_multiplier) -> float:
    X = pd.DataFrame([{
        'category_enc':        category_enc,
        'day_of_week':         day_of_week,
        'month':               month,
        'is_weekend':          is_weekend,
        'current_price':       price,
        'base_price':          base_price,
        'price_to_base':       price / base_price,
        'price_vs_competitor': price / competitor_price - 1,
        'season_multiplier':   season_multiplier,
        'competitor_price':    competitor_price,
    }])
    return max(0.0, float(demand_model.predict(X[FEATURES])[0]))


def optimise_price(req: PricingRequest):
    category = req.category if req.category in metadata['categories'] else metadata['categories'][0]
    cat_enc  = int(le_cat.transform([category])[0])

    floor   = req.base_cost * metadata['price_floor_pct']
    ceiling = req.base_price * metadata['price_ceiling_pct']
    prices  = np.linspace(floor, ceiling, metadata['n_price_points'])

    results = []
    for price in prices:
        demand  = predict_demand(price, cat_enc, req.base_price, req.competitor_price,
                                 req.day_of_week, req.month, req.is_weekend, req.season_multiplier)
        revenue = price * demand
        margin  = (price - req.base_cost) * demand
        margin_pct = (price - req.base_cost) / price

        results.append({
            'price':        round(float(price), 2),
            'demand':       round(demand, 1),
            'revenue':      round(revenue, 2),
            'margin':       round(margin, 2),
            'margin_pct':   round(margin_pct, 4),
            'vs_competitor':round(price / req.competitor_price - 1, 4),
        })

    df = pd.DataFrame(results)

    if req.strategy == 'margin':
        idx = df['margin'].idxmax()
    elif req.strategy == 'revenue':
        idx = df['revenue'].idxmax()
    else:
        df['score'] = (
            0.5 * df['margin']  / df['margin'].max() +
            0.5 * df['revenue'] / df['revenue'].max()
        )
        idx = df['score'].idxmax()

    optimal    = df.iloc[idx]
    top3_idx   = df.nlargest(3, 'margin' if req.strategy != 'revenue' else 'revenue').index
    top3       = df.iloc[top3_idx].to_dict(orient='records')

    return optimal.to_dict(), top3


@app.get("/")
def root():
    return {
        "service": "Dynamic Pricing Optimizer",
        "version": metadata["version"],
        "strategies": metadata["strategies"]
    }


@app.post("/recommend", response_model=PricingRecommendation)
def recommend_price(req: PricingRequest):
    try:
        optimal, top3 = optimise_price(req)

        price_change_pct = round(
            (optimal['price'] - req.base_price) / req.base_price * 100, 2
        )

        direction = "INCREASE" if price_change_pct > 1 else \
                    "DECREASE" if price_change_pct < -1 else "HOLD"

        return PricingRecommendation(
            product_id=req.product_id,
            recommended_price=optimal['price'],
            current_price=req.base_price,
            price_change_pct=price_change_pct,
            predicted_demand=optimal['demand'],
            predicted_revenue=optimal['revenue'],
            predicted_margin=optimal['margin'],
            margin_pct=optimal['margin_pct'],
            vs_competitor_pct=round(optimal['vs_competitor'] * 100, 2),
            strategy=req.strategy,
            price_direction=direction,
            ab_test_ready=True,
            top_3_alternatives=top3,
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/categories")
def list_categories():
    return {"categories": metadata["categories"]}


@app.get("/strategies")
def list_strategies():
    return {
        "strategies": {
            "margin":   "Maximise total profit margin",
            "revenue":  "Maximise total revenue",
            "balanced": "Balance margin and revenue equally"
        }
    }


@app.get("/model/info")
def model_info():
    return metadata