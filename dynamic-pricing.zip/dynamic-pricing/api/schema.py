from pydantic import BaseModel, Field
from typing import Optional

class PricingRequest(BaseModel):
    product_id:       int    = Field(..., description="Product identifier")
    category:         str    = Field(..., description="Product category")
    base_cost:        float  = Field(..., gt=0, description="Unit cost ($)")
    base_price:       float  = Field(..., gt=0, description="Current / reference price ($)")
    competitor_price: float  = Field(..., gt=0, description="Competitor price ($)")
    day_of_week:      int    = Field(..., ge=0, le=6, description="0=Monday 6=Sunday")
    month:            int    = Field(..., ge=1, le=12)
    is_weekend:       int    = Field(..., ge=0, le=1)
    season_multiplier:float  = Field(1.0, ge=0.5, le=3.0)
    strategy:         str    = Field("margin", description="margin | revenue | balanced")

class PricePoint(BaseModel):
    price:       float
    demand:      float
    revenue:     float
    margin:      float
    margin_pct:  float
    vs_competitor: float

class PricingRecommendation(BaseModel):
    product_id:           int
    recommended_price:    float
    current_price:        float
    price_change_pct:     float
    predicted_demand:     float
    predicted_revenue:    float
    predicted_margin:     float
    margin_pct:           float
    vs_competitor_pct:    float
    strategy:             str
    price_direction:      str
    ab_test_ready:        bool
    top_3_alternatives:   list